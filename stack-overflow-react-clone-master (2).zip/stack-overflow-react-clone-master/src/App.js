import "bootstrap/dist/css/bootstrap.min.css";
import { Route } from "react-router-dom";
import Header from "./Components/Header/header";

function App() {
	return (
		<>
			<Header />
		</>
	);
}

export default App;
